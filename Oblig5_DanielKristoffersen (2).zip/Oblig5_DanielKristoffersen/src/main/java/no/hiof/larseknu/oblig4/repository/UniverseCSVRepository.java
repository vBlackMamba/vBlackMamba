package no.hiof.larseknu.oblig4.repository;


import no.hiof.larseknu.oblig4.model.CelestialBody;
import no.hiof.larseknu.oblig4.model.Planet;
import no.hiof.larseknu.oblig4.model.PlanetSystem;
import no.hiof.larseknu.oblig4.model.Star;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class UniverseCSVRepository implements IUniversityRepository {
    private String fileName;
    private BufferedReader br = null;

    // trenger bare å deklareres - ikke settes til new HashMap
    //private HashMap<String, PlanetSystem> planetSystemHashMap = new HashMap<>();
    private HashMap<String, PlanetSystem> planetSystemHashMap;

    public UniverseCSVRepository(String fileName) {
        this.fileName = fileName;
        lesFraCSV("planets_100.csv");
    }


    private HashMap<String, PlanetSystem> lesFraCSV(String fileName) {

        // siden vi tar inn en string - må vi oprette et File objekt.
        File file = new File(fileName);

        // lager ett nytt hashmap når vi leser fra filen
        HashMap<String, PlanetSystem> planetSystemHashMap = new HashMap<>();

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linje;

            // leser linje for linje i CSV filen
            // hver linje er en ny planet.
            while ((linje = br.readLine()) != null) {
                String[] deler = linje.split(",");

                // Siden vi ikke skal lage et nytt planetsystem for hver planet, kan vi sjekke
                // om planetsystemet er i hashmappen vår, hvis det ikke er der - så lager vi det
                //
                // dette blir feil - vi må sjekke om deler[0], som er navnet på planetsystemet
                // er i HashMapen vår fra før av. Navnet på planetsyystemet er en "key" og planetobjektet er en value.
                // if (!planetSystemHashMap.containsKey(deler)) {
                if (!planetSystemHashMap.containsKey(deler[0])) {
                    // vi bruker denne konstruktøren fra PlanetSystem-klassen:
                    // public PlanetSystem(String name, Star centerStar, String pictureUrl)
                    // men først må stjerne objektet bli laget.

                    Star star = new Star(deler[2], Double.parseDouble(deler[3]), Double.parseDouble(deler[4]), Double.parseDouble(deler[5]), deler[6]);
                    // deler[0] er navnet, deler[2] er pictureurl
                    planetSystemHashMap.put(deler[0], new PlanetSystem(deler[0], star, deler[1]));
                }
                // Over sjekket vi om planetsystemet eksisterte i HashMapen vår fra før av, hvis den ikke var der fra før - så ble den lagd over.
                // da kan vi hente planetsystem objetet og legge til planeten fra csv filen.
                PlanetSystem currentPlanetSystem = planetSystemHashMap.get(deler[0]);
                // dette blir feil:
                /*
                currentPlanetSystem.getCenterStar(new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                        Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), star ,deler[13]));
                */
                // vi tar planetSystemet vi hentet over. og legger til en planet. Vi henter stjerne objektet fra planetsystemet:
                // currentplanetSystem.getCenterStar() og legger det til i konstruktøren til planeten.
                currentPlanetSystem.addPlanet(new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                        Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), currentPlanetSystem.getCenterStar() ,deler[13]));


                    System.out.println(planetSystemHashMap);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        // System.out.println(planetSystemHashMap);
        // så returnerer vi hele planetsystem hashmapen
        return planetSystemHashMap;
    }


    @Override
    public PlanetSystem getPlanetSystem(String planetSystemName) {
        return null;
    }

    @Override
    public ArrayList<PlanetSystem> getPlanetSystems() {
        return null;
    }

    @Override
    public Planet getPlanet(String planetSystemName, String planetName) {
        return getPlanetSystem(planetSystemName).getPlanet(planetName);
    }

    @Override
    public ArrayList<Planet> getPlanets(String planetSystemName) {
        return getPlanetSystem(planetSystemName).getPlanets();
    }

    @Override
    public HashMap<String, PlanetSystem> planetSystemHashMap(File fileName) {
        return lesFraCSV("planets_100.csv");
    }

    /*@Override
    public Planet opprettPlanet(String planetSystemName, Planet enPlanet) {
        return null;
    }*/

    @Override
    public Planet slettPlanet(String planetSystemName, Planet enPlanet) {
        return null;
    }
}













