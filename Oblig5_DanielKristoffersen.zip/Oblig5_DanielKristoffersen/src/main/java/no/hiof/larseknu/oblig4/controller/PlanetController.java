package no.hiof.larseknu.oblig4.controller;

import io.javalin.http.Context;
import no.hiof.larseknu.oblig4.model.Planet;
import no.hiof.larseknu.oblig4.repository.IUniversityRepository;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class PlanetController {
    private IUniversityRepository universityRepository;

    public PlanetController(IUniversityRepository universityRepository) {
        this.universityRepository = universityRepository;
    }

    public void getPlanets(Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String sortBy = context.queryParam("sort_by");

        ArrayList<Planet> planets = universityRepository.getPlanets(planetSystemName);

        if (sortBy != null) {
            switch (sortBy) {
                case "name":
                    Collections.sort(planets);
                    break;
                case "mass":
                    planets.sort((o1, o2) -> (int) (o1.getMass() - o2.getMass()));
                    break;
                case "radius":
                    planets.sort((o1, o2) -> {
                        if (o1.getRadius() < o2.getRadius())
                            return -1;
                        else if(o1.getRadius() > o2.getRadius())
                            return 1;
                        return 0;
                    });
                    break;
            }
        }


        context.json(planets);
    }

    public void getPlanet(Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String planetName = context.pathParam("planet-id");

        context.json(universityRepository.getPlanet(planetSystemName, planetName));
    }

    public void slettPlanet (Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String planetName = context.pathParam("planet-id");
        Planet enPlanet = universityRepository.getPlanet(planetSystemName, planetName);
        universityRepository.slettPlanet(planetSystemName, enPlanet);
        context.redirect("/planet-systems/" + planetSystemName);
    }


    public void update(Context context) {
        String planetSystemName = context.pathParam(":planet-system-id");
        String planetName = context.pathParam(":planet-id");
        Planet planet = opprettPlanet(context);

        universityRepository.updatePlanet(planetSystemName, planetName, planet);

        context.redirect("/planet-systems/" + planetSystemName);
    }

    public Planet opprettPlanet (Context context) {
        String planetSystemName = context.pathParam("planet-system-id");
        String name = context.formParam("name");
        double mass = Double.parseDouble(context.formParam("mass"));
        double radius = Double.parseDouble(context.formParam("radius"));
        double semiMajorAxis = Double.parseDouble(context.formParam("semiMajorAxis"));
        double eccentricity = Double.parseDouble(context.formParam("eccentricity"));
        double orbitalPeriod = Double.parseDouble(context.formParam("orbitalPeriod"));
        String pictuerUrl = context.formParam("pictureUrl");
        Planet nyPlanet = new Planet(name, mass, radius, semiMajorAxis, eccentricity, orbitalPeriod, null, pictuerUrl);
        universityRepository.opprettPlanet(planetSystemName, nyPlanet);
        context.redirect("/planet-systems/" + planetSystemName);

        return new Planet();
    }
}





