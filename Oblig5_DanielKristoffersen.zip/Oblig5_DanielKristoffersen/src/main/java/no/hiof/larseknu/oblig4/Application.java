package no.hiof.larseknu.oblig4;

import io.javalin.Javalin;
import io.javalin.plugin.rendering.vue.VueComponent;
import no.hiof.larseknu.oblig4.controller.PlanetController;
import no.hiof.larseknu.oblig4.controller.PlanetSystemController;
import no.hiof.larseknu.oblig4.repository.*;


public class Application {



    public static void main(String[] args) {
        Javalin app = Javalin.create().start(7001);

        app.config.enableWebjars();

        app.before("/", ctx -> ctx.redirect("/planet-systems"));


        UniverseRepository universeRepository = new UniverseRepository();
        UniverseJSONRepository universeJSONRepository = new UniverseJSONRepository("planets_4000.json");
        PlanetSystemController planetSystemController = new PlanetSystemController(universeJSONRepository);
        PlanetController planetController = new PlanetController(universeJSONRepository);


        /*UniverseCSVRepository universeCSVRepository = new UniverseCSVRepository("planets_100.csv");
        PlanetSystemController planetSystemController = new PlanetSystemController(universeCSVRepository);
        PlanetController planetController = new PlanetController(universeCSVRepository);*/




        app.get("/planet-systems", new VueComponent("planet-system-overview"));
        app.get("/planet-systems/:planet-system-id", new VueComponent("planet-system-detail"));
        app.get("/planet-systems/:planet-system-id/planets/:planet-id", new VueComponent("planet-detail"));
        app.get("/planet-systems/:planet-system-id/createplanet", new VueComponent("planet-create"));
        app.get("/planet-systems/:planet-system-id/planets/:planet-id/updateplanet", new VueComponent("planet-update"));


        app.get("api/planet-systems", planetSystemController::getAllPlanetSystems);
        app.get("api/planet-systems/:planet-system-id", planetSystemController::getPlanetSystem);

        app.get("/api/planet-systems/:planet-system-id/planets", planetController::getPlanets);
        app.get("/api/planet-systems/:planet-system-id/planets/:planet-id", planetController::getPlanet);
        app.post("/api/planet-systems/:planet-system-id/createplanet", planetController::opprettPlanet);
        app.post("/api/planet-systems/:planet-system-id/planets/:planet-id/updateplanet", planetController::update);
        app.get("/api/planet-systems/:planet-system-id/planets/:planet-id/delete", planetController::slettPlanet);




    }
}
