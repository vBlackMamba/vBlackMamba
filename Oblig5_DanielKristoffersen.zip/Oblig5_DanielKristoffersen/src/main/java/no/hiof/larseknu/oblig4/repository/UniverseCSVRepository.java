package no.hiof.larseknu.oblig4.repository;


import no.hiof.larseknu.oblig4.model.CelestialBody;
import no.hiof.larseknu.oblig4.model.Planet;
import no.hiof.larseknu.oblig4.model.PlanetSystem;
import no.hiof.larseknu.oblig4.model.Star;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class UniverseCSVRepository implements IUniversityRepository {
    private String fileName;
    private BufferedReader br = null;
    private HashMap<String, PlanetSystem> planetSystemHashMap = new HashMap<>();


    public UniverseCSVRepository(String fileName) {
        this.fileName = fileName;
        lesFraCSV("planets_100.csv");
    }


    private HashMap<String, PlanetSystem> lesFraCSV(String fileName) {

        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String linje;

            while ((linje = br.readLine()) != null) {
                String[] deler = linje.split(",");

                if (!planetSystemHashMap.containsKey(deler)) {
                    planetSystemHashMap.put(deler[0], new PlanetSystem());
                    Star star = new Star(new Star(deler[2], Double.parseDouble(deler[3]), Double.parseDouble(deler[4]), Double.parseDouble(deler[5]), deler[6]));
                }

                PlanetSystem currentPlanetSystem = planetSystemHashMap.get(deler[0]);
                currentPlanetSystem.getCenterStar(new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                        Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), star ,deler[13]));

                System.out.println(planetSystemHashMap);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return null;
    }




    /*private static HashMap<String, PlanetSystem> lesFraCSV(File filSomLesesFra) {
        HashMap<String, PlanetSystem> planetSystemerFraFil = new HashMap<>();

        try (BufferedReader bufretLeser = new BufferedReader(new FileReader(filSomLesesFra))) {
            String linje;

            while ((linje = bufretLeser.readLine()) != null) {
                String[] deler = linje.split(",");

                Star star = new Star(deler[2], Double.parseDouble(deler[3]), Double.parseDouble(deler[4]), Double.parseDouble(deler[5]), deler[6]);

                Planet planet = new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                        Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), star , deler[13]);

                PlanetSystem Systems = new PlanetSystem(deler[0], star , deler[1]);
                Systems.addPlanet(planet);

                if (!planetSystemerFraFil.containsKey(Systems.getName())) {
                    planetSystemerFraFil.put(Systems.getName(), Systems);

                    //}else if (planetSystemerFraFil.containsKey(Systems.getName())){
                    //continue;
                }else {
                    planetSystemerFraFil.get(Systems.getName()).addPlanet(planet);

                }*/


  /*if (planetSystemHashMap.containsKey(deler)){
                   planetSystem = planetSystem.getName();
                   star = planetSystem.getCenterStar();
               }else {
                   star = new Star();
                   planetSystem = new PlanetSystem();
               }
                }*/



    @Override
    public PlanetSystem getPlanetSystem(String planetSystemName) {
        return null;
    }

    @Override
    public ArrayList<PlanetSystem> getPlanetSystems() {
        return null;
    }

    @Override
    public Planet getPlanet(String planetSystemName, String planetName) {
        return getPlanetSystem(planetSystemName).getPlanet(planetName);
    }

    @Override
    public ArrayList<Planet> getPlanets(String planetSystemName) {
        return getPlanetSystem(planetSystemName).getPlanets();
    }

    @Override
    public HashMap<String, PlanetSystem> planetSystemHashMap(File fileName) {
        return lesFraCSV("planets_100.csv");
    }
}













