package no.hiof.larseknu.oblig4.repository;


import kotlin.reflect.jvm.internal.impl.renderer.RenderingFormat;
import no.hiof.larseknu.oblig4.model.CelestialBody;
import no.hiof.larseknu.oblig4.model.Planet;
import no.hiof.larseknu.oblig4.model.PlanetSystem;
import no.hiof.larseknu.oblig4.model.Star;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;

public class UniverseCSVRepository implements IUniversityRepository {

    private HashMap<String, PlanetSystem> planetSystemHashMap = new HashMap<>();

    public UniverseCSVRepository(String fileName) {
        lesFraCSV(fileName);
    }


    private void lesFraCSV(String fileName) {

        // siden vi tar inn en string - må vi oprette et File objekt.
        File file = new File(fileName);

        // lager ett nytt hashmap når vi leser fra filen

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String linje;

            // leser linje for linje i CSV filen
            // hver linje er en ny planet.
            while ((linje = br.readLine()) != null) {
                String[] deler = linje.split(",");


                if (!planetSystemHashMap.containsKey(deler[0])) {
                    // vi bruker denne konstruktøren fra PlanetSystem-klassen:
                    // public PlanetSystem(String name, Star centerStar, String pictureUrl)
                    // men først må stjerne objektet bli laget.

                    Star star = new Star(deler[2], Double.parseDouble(deler[3]), Double.parseDouble(deler[4]), Double.parseDouble(deler[5]), deler[6]);
                    // deler[0] er navnet, deler[2] er pictureurl
                    planetSystemHashMap.put(deler[0], new PlanetSystem(deler[0], star, deler[1]));
                }
                // Over sjekket vi om planetsystemet eksisterte i HashMapen vår fra før av, hvis den ikke var der fra før - så ble den lagd over.
                // da kan vi hente planetsystem objetet og legge til planeten fra csv filen.
                PlanetSystem currentPlanetSystem = planetSystemHashMap.get(deler[0]);

                // vi tar planetSystemet vi hentet over. og legger til en planet. Vi henter stjerne objektet fra planetsystemet:
                // currentplanetSystem.getCenterStar() og legger det til i konstruktøren til planeten.
                currentPlanetSystem.addPlanet(new Planet(deler[7], Double.parseDouble(deler[8]), Double.parseDouble(deler[9]), Double.parseDouble(deler[10]),
                        Double.parseDouble(deler[11]), Double.parseDouble(deler[12]), currentPlanetSystem.getCenterStar() ,deler[13]));

                planetSystemHashMap.put(deler[0], currentPlanetSystem);


                    System.out.println(planetSystemHashMap);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }



    // Denne oppgaven fikk jeg desverre ikke til, har begynt men er et eller annet som ikke stemmer. Fikk hjelp til å starte i øvningstimen. Men kom ikke stort lenger alikevel....
   /* public void lesFraCSV(File filSomSkrivesTil) throws IOException {
        ArrayList<PlanetSystem> planetSystemArrayList = new ArrayList<>(PlanetSystems.values()) {
            try (BufferedWriter bufretSkriver = new BufferedWriter(new FileWriter(filSomSkrivesTil))) {

                for (PlanetSystem planetSystem : PlanetSystemArrayList) {
                    for (Planet planet : planetSystem.getPlanets()) {

                        bufretSkriver.write(planetSystem.getName() + ",");
                        bufretSkriver.write(planetSystem.getPictureUrl() + ",");
                        bufretSkriver.write(planetSystem.getCenterStar().getMass() + ",");
                        bufretSkriver.write(planetSystem.getCenterStar().getRadius() + ",");
                        bufretSkriver.write(planetSystem.getCenterStar().getEffectiveTemperature() + ",");
                        bufretSkriver.write(planetSystem.getCenterStar().getPictureUrl() + ",");

                    }
                }
        }
    }*/
    // Denne oppgaven fikk jeg desverre ikke til


    @Override
    public PlanetSystem getPlanetSystem(String planetSystemName) {
        return planetSystemHashMap.get(planetSystemName);
    }

    @Override
    public ArrayList<PlanetSystem> getPlanetSystems() {
        return new ArrayList<>(planetSystemHashMap.values());
    }

    @Override
    public Planet getPlanet(String planetSystemName, String planetName) {
        return getPlanetSystem(planetSystemName).getPlanet(planetName);
    }

    @Override
    public ArrayList<Planet> getPlanets(String planetSystemName) {
        return getPlanetSystem(planetSystemName).getPlanets();
    }

    @Override
    public void opprettPlanet(String planetSystemName, Planet enPlanet) {

    }

    @Override
    public void updatePlanet(String systemName, String planetSystemName, Planet enPlanet) {

    }

    @Override
    public void slettPlanet(String planetSystemName, Planet enPlanet) {

    }
}













