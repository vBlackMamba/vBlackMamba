package no.hiof.larseknu.oblig4.repository;

import no.hiof.larseknu.oblig4.model.Planet;
import no.hiof.larseknu.oblig4.model.PlanetSystem;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;

public interface IUniversityRepository {
    PlanetSystem getPlanetSystem(String planetSystemName);
    ArrayList<PlanetSystem> getPlanetSystems();
    Planet getPlanet(String planetSystemName, String planet);
    ArrayList<Planet> getPlanets(String planetSystemName);


    //Opprette en planet
    void opprettPlanet (String planetSystemName, Planet enPlanet);

    //Oppdatere en planet
    void updatePlanet(String systemName, String planetSystemName, Planet enPlanet);

    //Slette en planet
    void slettPlanet (String planetSystemName, Planet enPlanet);
}
